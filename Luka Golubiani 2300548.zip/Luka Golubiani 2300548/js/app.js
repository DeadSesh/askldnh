// Smooth scroll მოქმედება მენიუს ბმულებზე (index.html-თან შესაბამისი)
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener("click", function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

// გალერეის ფოტოებზე დაკლიკებისას ვიზუალური ეფექტი (index.html-სთვის)
let galleryImages = document.querySelectorAll(".gallery-grid img");
galleryImages.forEach(img => {
  img.addEventListener("click", () => {
    img.classList.toggle("active");
  });
});

// ფორმის ვალიდაცია დაჯავშნის გვერდზე
const form = document.querySelector("form");
if (form) {
  form.addEventListener("submit", e => {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const date = document.getElementById("date").value;

    // 👇 თუ რომელიმე ველი ცარიელია — აჩვენე შეტყობინება და არ გაუშვა ფორმა
    if (!name || !email || !date) {
      alert("გთხოვთ შეავსოთ ყველა ველი");
      e.preventDefault(); // ხელს უშლის გაგზავნას
    } else {
      // 👇 წარმატების შემთხვევაში აჩვენე შეტყობინება
      alert("თქვენი დაჯავშნა წარმატებით განხორციელდა!");
    }
  });
}
